# CalculatorDesktop
 JAVAFx APLICATION
 
 ## Instalation
 
 Open Whit Intellij Idea and reload the ponm.xml
 
 Compile App.java and Runn
 
